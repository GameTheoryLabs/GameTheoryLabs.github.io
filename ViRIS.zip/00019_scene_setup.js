var GlobalRobot   = null ;
var GlobalComSat  = null ;
var GlobalStation = null ;
var GlobalCharger = null ;

function makeNewMinefac()
{	
	GlobalTaskManager.queueCommunication( GlobalComSat.ENTITY_ID , GlobalStation.ENTITY_ID ) ;
	
	GlobalTaskManager.queueMove  ( 4000 ,  4000 , 3000 , true ) ;
	GlobalTaskManager.queueBuild ( 8000 ,  8000 ) ;
	GlobalTaskManager.queueCommunication( GlobalComSat.ENTITY_ID , GlobalStation.ENTITY_ID ) ;
	GlobalTaskManager.queueWait  ( 1000 ) ;
	
	GlobalTaskManager.queueMove  ( 4000 , -4000 , 3000 , true ) ;
	GlobalTaskManager.queueBuild ( 8000 , -8000 ) ;
	GlobalTaskManager.queueCommunication( GlobalComSat.ENTITY_ID , GlobalStation.ENTITY_ID ) ;
	GlobalTaskManager.queueWait  ( 1000 ) ;
	
	GlobalTaskManager.queueMove  ( -4000 , -4000 , 3000 , true ) ;
	GlobalTaskManager.queueBuild ( -8000 , -8000 ) ;
	GlobalTaskManager.queueCommunication( GlobalComSat.ENTITY_ID , GlobalStation.ENTITY_ID ) ;
	GlobalTaskManager.queueWait  ( 1000 ) ;
	
	GlobalTaskManager.queueMove  ( -4000 ,  4000 , 3000 , true ) ;
	GlobalTaskManager.queueBuild ( -8000 ,  8000 ) ;
	GlobalTaskManager.queueCommunication( GlobalComSat.ENTITY_ID , GlobalStation.ENTITY_ID ) ;
	GlobalTaskManager.queueWait  ( 1000 ) ;
	
	GlobalTaskManager.queueMove  ( 0 , 0 , 3000 , false ) ;
}

function initScene()
{	
	//Lighting Setup
	var ambient = new THREE.AmbientLight( 0x121212 ) ;
	gworld.scene.add( ambient ) ;
	
	var directionalLight = new THREE.DirectionalLight( 0xbebebe , 1.75 ) ;
	directionalLight.position.set( 0.25 , 1 , 1 ) ;
	gworld.scene.add( directionalLight ) ;
	
	//create the platform
	GlobalEntityManager.createPlatform( 0 , 0 , 0 , 0.0025 ) ;
	
	GlobalStation = GlobalEntityManager.createStation( 0 , -75000 , -250000 , 0.00001 ) ;
	
	GlobalComSat = GlobalEntityManager.createComSat( -7500 , 0 , 0 , 0.001 ) ;
	
	GlobalCharger = GlobalEntityManager.createCharger( 0 , 0 , 0 ) ;
	
	GlobalRobot = GlobalEntityManager.createRobot( 0 , 0 , 0 , 0.001 ) ;
	
	gworld.startStaticMeshGroup( TEX_CANCER_LEVEL );
	gworld.createStaticPlane( 0 , 0 , 0 , -PI_2 , 0 , 0 , 21500 , 20480 , 150 , 150 ) ;
	GlobalCancerLevel = gworld.closeStaticMeshGroup();
	gworld.scene.add( GlobalCancerLevel ) ;
	GlobalCancerLevel.material.transparent = true;
	GlobalCancerLevel.material.opacity = 0.0;
	
	
	GlobalCancerLevel.fadeIn = function(){
			GlobalCancerLevel.fadeInTween = new TWEEN.Tween({op: 0.0}).to({op:1.0}, 3000)
			GlobalCancerLevel.fadeInTween.onUpdate(function(){
					GlobalCancerLevel.material.opacity =  this.op;
				});
			GlobalCancerLevel.material.visible = true;
			GlobalCancerLevel.fadeInTween.start();
		};
	
	GlobalCancerLevel.fadeOut = function(){
			GlobalCancerLevel.fadeOutTween = new TWEEN.Tween({op: 1.0}).to({op:0.0}, 3000);
			GlobalCancerLevel.fadeOutTween.onUpdate(function(){
					GlobalCancerLevel.material.opacity =  this.op;
				});
			GlobalCancerLevel.fadeOutTween.onComplete(function(){
					GlobalCancerLevel.material.visible = false;
				});
			GlobalCancerLevel.fadeOutTween.start();
		};
	GlobalCancerLevel.SetActive = function(){
		GlobalCancerLevel.fadeIn();
		GlobalGameLevel.fadeOut();
		GlobalGameLevel.active = false;
		GlobalCancerLevel.active = true;
	}
	GlobalCancerLevel.active = false;
	
	gworld.startStaticMeshGroup( TEX_FLOOR_TILE ) ;
	gworld.createStaticPlane( 0 , 0 , 0 , -PI_2 , 0 , 0 , 21500 , 20480 , 150 , 150 ) ;
	GlobalGameLevel = gworld.closeStaticMeshGroup() ;
	gworld.scene.add( GlobalGameLevel ) ;
	GlobalGameLevel.material.transparent = true;
	GlobalGameLevel.material.opacity = 1.0;
	
	GlobalGameLevel.fadeIn = function(){
			GlobalGameLevel.fadeInTween = new TWEEN.Tween({op: 0.0}).to({op:1.0}, 3000)
			GlobalGameLevel.fadeInTween.onUpdate(function(){
					GlobalGameLevel.material.opacity =  this.op;
				});
			GlobalGameLevel.material.visible = true;
			GlobalGameLevel.fadeInTween.start();
		};
	
	GlobalGameLevel.fadeOut = function(){
			GlobalGameLevel.fadeOutTween = new TWEEN.Tween({op: 1.0}).to({op:0.0}, 3000);
			GlobalGameLevel.fadeOutTween.onUpdate(function(){
					GlobalGameLevel.material.opacity =  this.op;
				});
			GlobalGameLevel.fadeOutTween.onComplete(function(){
					GlobalGameLevel.material.visible = false;
				});
			GlobalGameLevel.fadeOutTween.start();
		};
	GlobalGameLevel.SetActive = function(){
		GlobalGameLevel.fadeIn();
		GlobalCancerLevel.fadeOut();
		GlobalGameLevel.active = true;
		GlobalCancerLevel.active = false;
	}
	GlobalGameLevel.active = true;
	
	gworld.startStaticMeshGroup( TEX_FLOOR_GRATING , 1.0 ) ;
	gworld.createStaticPlane( -12800 , 5 , 0 , -PI_2 , 0 , 0 , 4200 , 11500 , 100 , 100 ) ;
	gworld.createStaticPlane(  12800 , 5 , 0 , -PI_2 , 0 , 0 , 4200 , 11500 , 100 , 100 ) ;
	gworld.scene.add( gworld.closeStaticMeshGroup() ) ;
}