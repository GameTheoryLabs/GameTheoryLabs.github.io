/************************
 * GRAPHICS DEFINITIONS *
 ***********************/

//models
const MODEL_PLAT_BORDER    = 3  ;
const MODEL_PLAT_FAN       = 4  ;
const MODEL_STATION        = 5  ;
const MODEL_COM_SAT_BASE   = 6  ;
const MODEL_COM_SAT_DISH   = 7  ;
const MODEL_MINE_FAC_BASE  = 8  ;
const MODEL_MINE_FAC_FAN   = 9  ;
const MODEL_MINE_FAC_WHEEL = 10 ;
const MODEL_MINE_FAC_FULL  = 11 ;
const MODEL_CHARGER        = 12 ;
const MODEL_ROBOT          = 13 ;

//textures
const TEX_FLOOR_GRATING = 100 ;
const TEX_FLOOR_TILE    = 101 ;
const TEX_CANCER_LEVEL  = 102 ;
const TEX_PRIMARY_3DRT  = 103 ;
const TEX_COM_SAT       = 104 ;
const TEX_MINE_FAC      = 105 ;

//materials
const MAT_BUILD_WIREFRAME       = 5000 ;
const MAT_BUILD_SPHERE          = 5001 ;
const MAT_BUILD_LASER_CONE      = 5002 ;
const MAT_BUILD_LASER_LINE      = 5003 ;
const MAT_BUILD_LASER_LINE_GLOW = 5004 ;
const MAT_ROBOT_HOVER           = 5005 ;
const MAT_ROBOT_SCAN            = 5006 ;
const MAT_COM_WAVE              = 5007 ;
const MAT_PRIMARY_3DRT          = 5008 ;
const MAT_COM_SAT               = 5009 ;
const MAT_MINE_FAC              = 5010 ;

//geoms
const GEOM_BUILD_LASER_CONE = 10000 ;
const GEOM_BUILD_LASER_LINE = 10001 ;
const GEOM_ROBOT_HOVER      = 10002 ;
const GEOM_ROBOT_SCAN       = 10003 ;

//mesh
const MESH_COM_WAVE = 20000 ;

AssetLoader = function()
{
	const buildLaserLength = 4000 ;
	const robotScanLength  = 2500 ;

	//Set Skybox Model
	gworld.setSkybox( "images/skybox/space_pos_x.png" ,
            		  "images/skybox/space_neg_x.png" ,
		              "images/skybox/space_pos_y.png" ,
		              "images/skybox/space_neg_y.png" ,
		              "images/skybox/space_pos_z.png" ,
		              "images/skybox/space_neg_z.png" ) ;
	
	const NUM_PHASES = 36    ;
	var   loadPhase  = 0     ;
	var   activeLoad = false ;
	
	function loadPrimary3DRTTex()
	{
		gworld.createNewTexture( "images/3drt_const_kit_blue.jpg" , true , 1  , 1 , TEX_PRIMARY_3DRT , finished ) ;
		activeLoad = true ;
	}
	
	function loadPrimary3DRTMat()
	{
		var mat = new THREE.MeshLambertMaterial( { map : gworld.getGfxObjPtr( TEX_PRIMARY_3DRT ) } ) ;
		gworld.storeNewGfxObj( MAT_PRIMARY_3DRT ,  mat ) ;
		finished( MAT_PRIMARY_3DRT ) ;
	}
	
	function loadComSatTex()
	{
		gworld.createNewTexture( "models/com_sat/com_sat.jpg" , true , 1  , 1 , TEX_COM_SAT , finished ) ;
		activeLoad = true ;
	}
	
	function loadComSatMat()
	{
		var mat = new THREE.MeshLambertMaterial( { map   : gworld.getGfxObjPtr( TEX_COM_SAT ) ,
			                                       color : 0xaaaaaa } );
		gworld.storeNewGfxObj( MAT_COM_SAT , mat ) ;
		finished( MAT_COM_SAT ) ;
	}
	
	function loadMineFacTex()
	{
		gworld.createNewTexture( "models/mine_fac/mine_fac.jpg" , true , 1  , 1 , TEX_MINE_FAC , finished ) ;
		activeLoad = true ;
	}
	
	function loadMineFacMat()
	{
		var mat = new THREE.MeshLambertMaterial( { map   : gworld.getGfxObjPtr( TEX_MINE_FAC ) ,
			                                       color : 0xaaaaaa } );
		gworld.storeNewGfxObj( MAT_MINE_FAC , mat ) ;
		finished( MAT_MINE_FAC ) ;
	}
	
	function loadBuildWireframeMat()
	{
		var mat = new THREE.MeshLambertMaterial( { color     : 0x3333ff             ,
			                                       ambient   : 0x1111ff             ,
			                                       emissive  : 0x1111ff             ,
			                                       wireframe : true                 ,
			                                       side      : THREE.FrontSide      ,
			                                       shading   : THREE.FlatShading    ,
			                                       blending  : THREE.NormalBlending
					                             } ) ;
		gworld.storeNewGfxObj( MAT_BUILD_WIREFRAME , mat ) ;
		finished( MAT_BUILD_WIREFRAME ) ;
	}
	
	function loadBuildSphereMat()
	{
		var mat = new THREE.ShaderMaterial( { uniforms       : SphereBuildUniforms              ,
                                              vertexShader   : SphereBuildShader.vertexShader   ,
                                              fragmentShader : SphereBuildShader.fragmentShader ,
                                              side           : THREE.FrontSide                  ,
                                              blending       : THREE.AdditiveBlending           ,
                                              transparent    : true                             ,
                                              wireframe      : true
                                            } ) ;
		gworld.storeNewGfxObj( MAT_BUILD_SPHERE , mat ) ;
		finished( MAT_BUILD_SPHERE ) ;
	}
	
	function loadBuildLaserConeMat()
	{
		var mat = new THREE.ShaderMaterial( { uniforms       : LaserBuildUniforms              ,
                                              vertexShader   : LaserBuildShader.vertexShader   ,
                                              fragmentShader : LaserBuildShader.fragmentShader ,
                                              side           : THREE.FrontSide                 ,
                                              blending       : THREE.AdditiveBlending          ,
                                              transparent    : true                            ,
                                              wireframe      : true
                                            } ) ;
		gworld.storeNewGfxObj( MAT_BUILD_LASER_CONE , mat ) ;
		finished( MAT_BUILD_LASER_CONE ) ;
	}
	
	function loadBuildLaserLineMat()
	{
		var mat = new THREE.MeshBasicMaterial( { color    : 0x9898ff ,
                                                 opacity  : 1.0      ,
                                                 blending : THREE.AdditiveBlending 
                                               } ) ;
		gworld.storeNewGfxObj( MAT_BUILD_LASER_LINE , mat ) ;
		finished( MAT_BUILD_LASER_LINE ) ;
	}
	
	function loadBuildLaserLineGlowMat()
	{
		var mat = new THREE.MeshLambertMaterial( { color    : 0x1118ff ,
	                                               opacity  : 1.0      ,
	                                               blending : THREE.AdditiveBlending 
	                                             } ) ;
		gworld.storeNewGfxObj( MAT_BUILD_LASER_LINE_GLOW , mat ) ;
		finished( MAT_BUILD_LASER_LINE_GLOW ) ;
	}
	
	function loadRobotHoverMat()
	{
		var mat = new THREE.ShaderMaterial( { uniforms       : RobotHoverUniforms              ,
		                                      vertexShader   : RobotHoverShader.vertexShader   ,
		                                      fragmentShader : RobotHoverShader.fragmentShader ,
		                                      side           : THREE.DoubleSide                ,
		                                      blending       : THREE.AdditiveBlending          ,
		                                      transparent    : true                            ,
		                                      wireframe      : true
		                                    } ) ;
		gworld.storeNewGfxObj( MAT_ROBOT_HOVER , mat ) ;
		finished( MAT_ROBOT_HOVER ) ;
	}
	
	function loadRobotScanMat()
	{
		var mat = new THREE.ShaderMaterial( { uniforms       : RobotScanUniforms              ,
 	                                          vertexShader   : RobotScanShader.vertexShader   ,
		                                      fragmentShader : RobotScanShader.fragmentShader ,
		                                      side           : THREE.DoubleSide               ,
		                                      blending       : THREE.AdditiveBlending         ,
		                                      transparent    : true                           ,
		                                      wireframe      : true
		                                    } ) ;
		gworld.storeNewGfxObj( MAT_ROBOT_SCAN , mat ) ;
		finished( MAT_ROBOT_SCAN ) ;
	}
	
	function loadComWaveMat()
	{
		var mat = new THREE.MeshLambertMaterial( { color       : 0x1118ff ,
			                                       opacity     : 1.0      ,
			                                       transparent : true     ,
			                                       blending    : THREE.AdditiveBlending 
			                                     } ) ;
		gworld.storeNewGfxObj( MAT_COM_WAVE , mat ) ;
		finished( MAT_COM_WAVE ) ;
	}
	
	function loadLaserConeGeom()
	{
		var geom = new THREE.CylinderGeometry( 0 , 1750 , buildLaserLength , 32 , 32 , true ) ;
		geom.applyMatrix( new THREE.Matrix4().makeTranslation( 0 , -buildLaserLength / 2 , 0 ) ) ;
		geom.applyMatrix( new THREE.Matrix4().makeRotationFromEuler( new THREE.Euler( -PI_2 , 0 , 0 , "XYZ" ) ) ) ;
		gworld.storeNewGfxObj( GEOM_BUILD_LASER_CONE , geom ) ;
		finished( GEOM_BUILD_LASER_CONE ) ;
	}
	
	function loadLaserLineGeom()
	{
		var geom = new THREE.CylinderGeometry( 20 , 10 , buildLaserLength , 5 , 5 , true ) ;
		geom.applyMatrix( new THREE.Matrix4().makeTranslation( 0 , -buildLaserLength / 2 , 0 ) ) ;
		geom.applyMatrix( new THREE.Matrix4().makeRotationFromEuler( new THREE.Euler( -PI_2 , 0 , 0 , "XYZ" ) ) ) ;
		gworld.storeNewGfxObj( GEOM_BUILD_LASER_LINE , geom ) ;
		finished( GEOM_BUILD_LASER_LINE ) ;
	}
	
	function loadRobotHoverGeom()
	{
		var geom = new THREE.CylinderGeometry( 500 , 100 , 1000 , 32 , 32 , true ) ;
		gworld.storeNewGfxObj( GEOM_ROBOT_HOVER , geom ) ;
		finished( GEOM_ROBOT_HOVER ) ;
	}
	
	function loadRobotScanGeom()
	{
		var geom = new THREE.CylinderGeometry( 0 , 1750 , robotScanLength , 32 , 32 , true ) ;
		geom.applyMatrix( new THREE.Matrix4().makeTranslation( 0 , ( -robotScanLength / 2 ) , 0 ) ) ;
		geom.applyMatrix( new THREE.Matrix4().makeScale( 1 , 1 , 0.1 ) ) ;
		geom.applyMatrix( new THREE.Matrix4().makeRotationFromEuler( new THREE.Euler( -PI_2 / 1.5 , 0 , 0 , "XYZ" ) ) ) ;
		gworld.storeNewGfxObj( GEOM_ROBOT_SCAN , geom ) ;
		finished( GEOM_ROBOT_SCAN ) ;
	}
	
	function loadComWaveMesh()
	{
		gworld.startStaticMeshGroup( MAT_COM_WAVE ) ;
		gworld.createStaticTorus( 0 , 0 ,   0  , 0 , 0 , 0 , 200 , 50 , 3 , 32 ) ;
		gworld.createStaticTorus( 0 , 0 , 600  , 0 , 0 , 0 , 200 , 50 , 3 , 32 ) ;
		gworld.createStaticTorus( 0 , 0 , 1200 , 0 , 0 , 0 , 200 , 50 , 3 , 32 ) ;
		gworld.createStaticTorus( 0 , 0 , 1800 , 0 , 0 , 0 , 200 , 50 , 3 , 32 ) ;
		var mesh = gworld.closeStaticMeshGroup() ;
		mesh.geometry.applyMatrix( new THREE.Matrix4().makeTranslation( 0 , 0 , -1800 ) ) ;
		gworld.storeNewGfxObj( MESH_COM_WAVE , mesh ) ;
		finished( MESH_COM_WAVE ) ;
	}
	
	function loadMainFloorTex()
	{
		gworld.createNewTexture( "images/metal_FloorHoles_1k_d.jpg" , true , 10 , 10 , TEX_FLOOR_TILE , finished ) ;
		activeLoad = true ;
	}
	
	function loadSideFloorTex()
	{
		gworld.createNewTexture( "images/transparent_grate.png" , true , 1  , 3 , TEX_FLOOR_GRATING , finished ) ;
		activeLoad = true ;
	}
	
	function loadCancerLevelTex()
	{
		gworld.createNewTexture( "images/cancer_level.jpg" , true , 1  , 1 , TEX_CANCER_LEVEL , finished ) ;
		activeLoad = true ;
	}
	
	function loadPlatBorderModel()
	{
		gworld.createNewObjMtlMesh( "models/platform/plat_border.obj" , "models/platform/plat_border.mtl" , MODEL_PLAT_BORDER , finished ) ;
		activeLoad = true ;
	}
	
	function loadPlatFanModel()
	{
		gworld.createNewObjMtlMesh( "models/platform/plat_fan.obj" , "models/platform/plat_fan.mtl" , MODEL_PLAT_FAN , finished ) ;
		activeLoad = true ;
	}
	
	function loadStationModel()
	{
		gworld.createNewObjMtlMesh( "models/station/station.obj" , "models/station/station.mtl" , MODEL_STATION , finished ) ;
		activeLoad = true ;
	}
	
	function loadComSatBaseModel()
	{
		gworld.createNewObjMtlMesh( "models/com_sat/com_sat_base.obj" , "models/com_sat/com_sat_base.mtl" , MODEL_COM_SAT_BASE , finished ) ;
		activeLoad = true ;
	}
	
	function loadComSatDishModel()
	{
		gworld.createNewObjMtlMesh( "models/com_sat/com_sat_dish.obj" , "models/com_sat/com_sat_dish.mtl" , MODEL_COM_SAT_DISH , finished ) ;
		activeLoad = true ;
	}
	
	function loadMineFacBaseModel()
	{
		gworld.createNewObjMtlMesh( "models/mine_fac/mine_fac_base.obj" , "models/mine_fac/mine_fac_base.mtl" , MODEL_MINE_FAC_BASE , finished ) ;
		activeLoad = true ;
	}
	
	function loadMineFacFanModel()
	{
		gworld.createNewObjMtlMesh( "models/mine_fac/mine_fac_fan.obj" , "models/mine_fac/mine_fac_fan.mtl" , MODEL_MINE_FAC_FAN , finished ) ;
		activeLoad = true ;
	}
	
	function loadMineFacWheelModel()
	{
		gworld.createNewObjMtlMesh( "models/mine_fac/mine_fac_wheel.obj" , "models/mine_fac/mine_fac_wheel.mtl" , MODEL_MINE_FAC_WHEEL , finished ) ;
		activeLoad = true ;
	}
	
	function loadMineFacFullModel()
	{
		gworld.createNewObjMtlMesh( "models/mine_fac/mine_fac_full.obj" , "models/mine_fac/mine_fac_full.mtl" , MODEL_MINE_FAC_FULL , finished ) ;
		activeLoad = true ;
	}
	
	function loadChargerModel()
	{
		gworld.createNewObjMtlMesh( "models/charger/charger.obj" , "models/charger/charger.mtl" , MODEL_CHARGER , finished ) ;
		activeLoad = true ;
	}
	
	function loadRobotModel()
	{
		gworld.createNewObjMtlMesh( "models/robot/robot.obj" , "models/robot/robot.mtl" , MODEL_ROBOT , finished ) ;
		activeLoad = true ;
	}
	
	function applyPrimary3DRTMat()
	{
		setSharedMat( MODEL_PLAT_BORDER , MAT_PRIMARY_3DRT ) ;
		setSharedMat( MODEL_PLAT_FAN    , MAT_PRIMARY_3DRT ) ;
		setSharedMat( MODEL_CHARGER     , MAT_PRIMARY_3DRT ) ;
		setSharedMat( MODEL_ROBOT       , MAT_PRIMARY_3DRT ) ;
		
		finished( -1 ) ;
	}
	
	function applyComSatMat()
	{
		setSharedMat( MODEL_COM_SAT_BASE , MAT_COM_SAT ) ;
		setSharedMat( MODEL_COM_SAT_DISH , MAT_COM_SAT ) ;
		
		finished( -1 ) ;
	}
	
	function applyMineFacMat()
	{
		setSharedMat( MODEL_MINE_FAC_BASE  , MAT_MINE_FAC ) ;
		setSharedMat( MODEL_MINE_FAC_FAN   , MAT_MINE_FAC ) ;
		setSharedMat( MODEL_MINE_FAC_WHEEL , MAT_MINE_FAC ) ;
		finished( -1 ) ;
	}
	
	// Set shared material id to the given mesh id's children
	function setSharedMat( meshID , matID )
	{
		var mesh = gworld.getGfxObjPtr( meshID ) ;
		var mat  = gworld.getGfxObjPtr( matID  ) ;
        
		for( var i = 0 ; i < mesh.children.length ; i++ )
        {
            mesh.children[ i ].material = mat ;
        }
	}
	
	function finished( id )
	{
		console.log( "LOADED ID:" , id ) ;

		loadPhase++ ;
		activeLoad = false ;
	}
	
	this.loadUpdate = function( delta )
	{
		if( !activeLoad )
		{
			switch( loadPhase )
			{
			case 0  : loadPrimary3DRTTex        () ; break ;
			case 1  : loadPrimary3DRTMat        () ; break ;
			case 2  : loadComSatTex             () ; break ;
			case 3  : loadComSatMat             () ; break ;
			case 4  : loadMineFacTex            () ; break ;
			case 5  : loadMineFacMat            () ; break ;
			case 6  : loadBuildWireframeMat     () ; break ;
			case 7  : loadBuildSphereMat        () ; break ;
			case 8  : loadBuildLaserConeMat     () ; break ;
			case 9  : loadBuildLaserLineMat     () ; break ;
			case 10 : loadBuildLaserLineGlowMat () ; break ;
			case 11 : loadRobotHoverMat         () ; break ;
			case 12 : loadRobotScanMat          () ; break ;
			case 13 : loadComWaveMat            () ; break ;
			case 14 : loadLaserConeGeom         () ; break ;
			case 15 : loadLaserLineGeom         () ; break ;
			case 16 : loadRobotHoverGeom        () ; break ;
			case 17 : loadRobotScanGeom         () ; break ;
			case 18 : loadComWaveMesh           () ; break ;
			case 19 : loadMainFloorTex          () ; break ;
			case 20 : loadSideFloorTex          () ; break ;
			case 21 : loadCancerLevelTex        () ; break ;
			case 22 : loadPlatBorderModel       () ; break ;
			case 23 : loadPlatFanModel          () ; break ;
			case 24 : loadStationModel          () ; break ;
			case 25 : loadComSatBaseModel       () ; break ;
			case 26 : loadComSatDishModel       () ; break ;
			case 27 : loadMineFacBaseModel      () ; break ;
			case 28 : loadMineFacFanModel       () ; break ;
			case 29 : loadMineFacWheelModel     () ; break ;
			case 30 : loadMineFacFullModel      () ; break ;
			case 31 : loadChargerModel          () ; break ;
			case 32 : loadRobotModel            () ; break ;
			case 33 : applyPrimary3DRTMat       () ; break ;
			case 34 : applyComSatMat            () ; break ;
			case 35 : applyMineFacMat           () ; break ;
			} ;
		}
		
		return ( loadPhase / NUM_PHASES ) ;
	} ;
} ;

var GlobalAssetLoader ;

function initAssetLoader()
{
	GlobalAssetLoader = new AssetLoader() ;
}
