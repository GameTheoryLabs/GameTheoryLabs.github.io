//Uniforms for the sphere hologram build shader
SphereBuildUniforms =
{
	"c"        : { type: "f"  , value : 0.02                           } ,
	"p"        : { type: "f"  , value : 1.0                            } ,
	"wave"     : { type: "f"  , value : 0.0                            } ,
	"alpha"    : { type: "f"  , value : 0.0                            } ,
	glowColor  : { type: "c"  , value : new THREE.Color   ( 0x2424ff ) } ,
	viewVector : { type: "v3" , value : new THREE.Vector3 ( 0 , 0 , -1 ) }
} ;

LaserBuildUniforms =
{
	"c"        : { type: "f"  , value : 0.02                             } ,
	"p"        : { type: "f"  , value : 1.0                              } ,
	"wave"     : { type: "f"  , value : 0.0                              } ,
	"alpha"    : { type: "f"  , value : 0.0                              } ,
	"iter"     : { type: "f"  , value : 0.0                              } ,
	glowColor  : { type: "c"  , value : new THREE.Color   ( 0x2424ff   ) } ,
	viewVector : { type: "v3" , value : new THREE.Vector3 ( -1 , 0 , 0 ) }
} ;

RobotHoverUniforms =
{
	"wave"     : { type: "f"  , value : 1.0                              } ,
	"alpha"    : { type: "f"  , value : 0.25                             } ,
	"iter"     : { type: "f"  , value : 0.0                              } ,
	glowColor  : { type: "c"  , value : new THREE.Color   ( 0x2727ff   ) } ,
	viewVector : { type: "v3" , value : new THREE.Vector3 ( -1 , 0 , 0 ) }
} ;

RobotScanUniforms =
{
	"wave"     : { type: "f"  , value : 1.0                              } ,
	"alpha"    : { type: "f"  , value : 0.75                             } ,
	"iter"     : { type: "f"  , value : 0.0                              } ,
	glowColor  : { type: "c"  , value : new THREE.Color   ( 0x2727ff   ) } ,
	viewVector : { type: "v3" , value : new THREE.Vector3 ( -1 , 0 , 0 ) }
} ;

SphereBuildShader =
{
	vertexShader:
	[
		"uniform vec3  viewVector ; " ,
		"uniform float c          ; " ,
		"uniform float p          ; " ,
		"varying float intensity  ; " ,
		"void main()" ,
		"{" ,
		    "vec3 vNormal   = normalize( normalMatrix * normal ) ; " ,
			"vec3 vNormel   = normalize( normalMatrix * viewVector ) ; " ,
			"float f        = abs( c - dot( vNormal, vNormel ) ) ; " ,
			"intensity      = pow( f, p ) ; " ,
		    "gl_Position    = projectionMatrix * modelViewMatrix * vec4( position, 1.0 ) ; " ,
		"}" ,
	].join( "\n" ) ,

	fragmentShader:
	[
		"uniform vec3  glowColor;",
		"uniform float alpha;",
		"uniform float wave;",
		"varying float intensity;",
		"void main()", 
		"{",
			"vec3 col     = vec3( glowColor.r * wave , glowColor.g * wave , glowColor.b );",
			"vec3 glow    = col * intensity;",
		    "gl_FragColor = vec4( glow, alpha );",
		"}",
	].join("\n")
} ;

LaserBuildShader =
{
	vertexShader:
	[
		"uniform vec3  viewVector     ; " ,
		"uniform float c              ; " ,
		"uniform float p              ; " ,
		"uniform float iter           ; " ,
		"varying float intensity      ; " ,
		"varying float alphaIntensity ; " ,
		"void main()", 
		"{",
		    "vec3 vNormal   = normalize( normalMatrix * normal     ) ; " ,
			"vec3 vNormel   = normalize( normalMatrix * viewVector ) ; " ,
			"float f        = abs( c - dot( vNormal, vNormel ) ) ; " ,
			"intensity      = pow( f, p ) ; " ,
			"gl_Position    = projectionMatrix * modelViewMatrix * vec4( position, 1.0 ) ; " ,
			"float xa       = ( 0.5 * sin( 0.0055 * position.z + iter ) + 1.0 ) ; " ,
			"float mod      = ( position.y > 0.0 ) ? 1.0 : -1.0 ; " ,
			"float ya       = ( 0.5 * sin( 0.0150 * position.y + ( iter * mod ) ) + 1.0 ) ; " ,
		    "float la       = 1.0 - ( position.z / 3500.0 ) ; " ,
		    "alphaIntensity = xa * ya * la ; " ,
		"}" ,
	].join( "\n" ) ,

	fragmentShader:
	[
		"uniform vec3  glowColor      ; " ,
		"uniform float alpha          ; " ,
		"uniform float wave           ; " ,
		"varying float intensity      ; " ,
		"varying float alphaIntensity ; " ,
		"void main()" , 
		"{" ,
			"vec3 col     = vec3( glowColor.r * wave , glowColor.g * wave , glowColor.b ) ; " ,
			"vec3 glow    = col * intensity ; " ,
		    "gl_FragColor = vec4( glow, alpha * alphaIntensity ) ; " ,
		"}" ,
	].join( "\n" )
} ;

RobotHoverShader =
{
	vertexShader:
	[
		"uniform vec3  viewVector     ; " ,
		"uniform float iter           ; " ,
		"varying float alphaIntensity ; " ,
		"void main()", 
		"{",
			"gl_Position    = projectionMatrix * modelViewMatrix * vec4( position, 1.0 ) ; " ,
			"float ya       = sin( 0.020 * position.y + iter ) ; " ,
			"float la       = cos( 0.002 * position.y ) ; " ,
		    "alphaIntensity = la * ya ; " ,
		"}" ,
	].join( "\n" ) ,

	fragmentShader:
	[
		"uniform vec3  glowColor      ; " ,
		"uniform float alpha          ; " ,
		"uniform float wave           ; " ,
		"varying float alphaIntensity ; " ,
		"void main()" , 
		"{" ,
			"vec3 col     = vec3( glowColor.r * wave , glowColor.g * wave , glowColor.b ) ; " ,
		    "gl_FragColor = vec4( col, alpha * alphaIntensity ) ; " ,
		"}" ,
	].join( "\n" )
} ;

RobotScanShader =
{
	vertexShader:
	[
		"uniform vec3  viewVector     ; " ,
		"uniform float iter           ; " ,
		"varying float alphaIntensity ; " ,
		"void main()", 
		"{",
			"gl_Position    = projectionMatrix * modelViewMatrix * vec4( position, 1.0 ) ; " ,
			"float ya       = sin( 1.0 * position.y + iter ) ; " ,
		    "alphaIntensity = ya ; " ,
		"}" ,
	].join( "\n" ) ,

	fragmentShader:
	[
		"uniform vec3  glowColor      ; " ,
		"uniform float alpha          ; " ,
		"uniform float wave           ; " ,
		"varying float alphaIntensity ; " ,
		"void main()" , 
		"{" ,
			"vec3 col     = vec3( glowColor.r * wave , glowColor.g * wave , glowColor.b ) ; " ,
		    "gl_FragColor = vec4( col, alpha * alphaIntensity ) ; " ,
		"}" ,
	].join( "\n" )
} ;