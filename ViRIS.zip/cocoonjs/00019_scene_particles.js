ParticleSystem = function ()
{
ParticleShader =
{
vertexShader:
[
"attribute float size;",
"attribute vec3 pcolor;",

"varying vec3 vColor;",

"void main() {",
"vColor = pcolor;",
"vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",
"gl_PointSize = size * ( 200.0 / length( mvPosition.xyz ) );",
"gl_Position = projectionMatrix * mvPosition;",
"}"
   
].join("\n"),

fragmentShader:
[
"uniform sampler2D texture;",

"varying vec3 vColor;",

"void main() {",
"vec4 outColor = texture2D( texture, gl_PointCoord );",
"gl_FragColor = outColor * vec4( vColor, 1.0 );",
"}"
].join("\n")
};

var group = new THREE.Object3D();
gworld.scene.add( group );

// Create particle objects for Three.js

var particlesLength = 1000;

var particles = new THREE.Geometry()

var Pool =
{
__pools: [],

// Get a new Vector
get: function()
{
if ( this.__pools.length > 0 )
{
return this.__pools.pop();
}

console.log( "pool ran out!" )
return null;
},

// Release a vector back into the pool
add: function( v )
{
this.__pools.push( v );
}
};

for ( i = 0; i < particlesLength; i ++ )
{
particles.vertices.push( new  THREE.Vector3( Math.random() * 200 - 100, Math.random() * 100 + 150, Math.random() * 50 ) );
Pool.add( i );
}


// Create pools of vectors

var sprite = generateSprite() ;

texture = new THREE.Texture( sprite );
texture.needsUpdate = true;

attributes =
{
size:  { type: 'f', value: [] },
pcolor: { type: 'c', value: [] }
};

uniforms =
{
texture:   { type: "t", value: texture }
};

function generateSprite()
{
var canvas = document.createElement( 'canvas' );
canvas.width = 128;
canvas.height = 128;

var context = canvas.getContext( '2d' );

context.beginPath();
context.arc( 64, 64, 60, 0, Math.PI * 2, false) ;

context.lineWidth = 0.5; //0.05
context.stroke();
context.restore();

var gradient = context.createRadialGradient( canvas.width / 2, canvas.height / 2, 0, canvas.width / 2, canvas.height / 2, canvas.width / 2 );

gradient.addColorStop( 0, 'rgba(255,255,255,1)' );
gradient.addColorStop( 0.2, 'rgba(255,255,255,1)' );
gradient.addColorStop( 0.4, 'rgba(200,200,200,1)' );
gradient.addColorStop( 1, 'rgba(0,0,0,1)' );

context.fillStyle = gradient;

context.fill();

return canvas;
}

var shaderMaterial = new THREE.ShaderMaterial(
{
uniforms: uniforms,
attributes: attributes,

vertexShader: ParticleShader.vertexShader,
fragmentShader: ParticleShader.fragmentShader,

blending: THREE.AdditiveBlending,
depthWrite: false,
transparent: true

});

var particleCloud = new THREE.ParticleSystem( particles, shaderMaterial );
particleCloud.dynamic = true;

var vertices = particleCloud.geometry.vertices;

for( var v = 0; v < vertices.length; v ++ )
{
attributes.pcolor.value[ v ] = new THREE.Color( 0x000000 );
particles.vertices[ v ].set( Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY );
}

group.add( particleCloud );

// Create Particle Systems

// EMITTER STUFF

var counter = 0 ;

var setTargetParticle = function()
{
counter++;

if( counter > particlesLength - 1)
{
counter = 0;
}

//var target = Pool.get();
attributes.size.value[ counter ] = Math.random() * 200 + 200;
return counter;
};

var onParticleCreated = function( p )
{
var target = p.target;
particles.vertices[ target ] = p.position;
attributes.pcolor.value[ target ].setRGB( 0.05, 0.05, 0.8 );
};

var onParticleDead = function( p )
{
var target = p.target;
//Pool.add( target );

particles.vertices[ target ].set( Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY );
};

var sparksEmitter = new SPARKS.Emitter( new SPARKS.SteadyCounter( 300 ) );

sparksEmitter.addInitializer( new SPARKS.Position( new SPARKS.PointZone( new THREE.Vector3( -2000, 500, -2000 ) ) ) );
sparksEmitter.addInitializer( new SPARKS.Lifetime( 3, 3 ));
sparksEmitter.addInitializer( new SPARKS.Target( null, setTargetParticle ) );

sparksEmitter.addInitializer( new SPARKS.Velocity( new SPARKS.PointZone( new THREE.Vector3( 2000, 0, 0 ) ) ) );

sparksEmitter.addAction( new SPARKS.Age() );
sparksEmitter.addAction( new SPARKS.Move() );

sparksEmitter.addCallback( "created", onParticleCreated );
sparksEmitter.addCallback( "dead", onParticleDead );
sparksEmitter.start();

var elapsed = 0 ;

this.update = function ( delta )
{
elapsed += delta ;
particleCloud.geometry.verticesNeedUpdate = true;
attributes.size.needsUpdate = true;
attributes.pcolor.needsUpdate = true;

//if( elapsed < 5000 )
sparksEmitter.step();
};
};

var pSystem ;

function initParticleSystem()
{
//pSystem = new ParticleSystem();
}

function updateParticleSystem( delta )
{
//pSystem.update( delta );
}